﻿  ALTER TABLE EmployeeStep
           ADD CurrentStep AS
   CASE
      WHEN(StatusId = 1) THEN StepId
      ELSE 'No Step In Progress'
    END
    ;
