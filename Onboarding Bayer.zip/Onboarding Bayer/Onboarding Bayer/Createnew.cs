﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Onboarding_Bayer
{
    public partial class Createnew : UserControl
    {
        // SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\gafar\OneDrive\Desktop\Onboarding Bayer\Onboarding Bayer\Database1.mdf;Integrated Security=True");

        private static Createnew _instance;

        public static Createnew Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new Createnew();
                return _instance;

            }

        }
        public Createnew()
        {
            InitializeComponent();
            FillcomboRole();
            FillcomboManager();
        }
        void FillcomboRole() {

            string constring = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\gafar\OneDrive\Desktop\Onboarding Bayer\Onboarding Bayer\BayerDatabase.mdf;Integrated Security=True";
            string Query = "Select * from ROLE; "; 
            SqlConnection conDataBase = new SqlConnection(constring);
            SqlCommand cmdDataBase = new SqlCommand(Query, conDataBase);
            SqlDataReader myReader;
            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();
                
                while (myReader.Read())
                {
                    string sName = myReader.GetString(1);
                    CmbRole.Items.Add(sName);     
                    
                }
            } 

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }


        }


        void FillcomboManager()
        {

            string constring = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\gafar\OneDrive\Desktop\Onboarding Bayer\Onboarding Bayer\BayerDatabase.mdf;Integrated Security=True";
            string Query = "Select * from ADMIN; ";
            SqlConnection conDataBase = new SqlConnection(constring);
            SqlCommand cmdDataBase = new SqlCommand(Query, conDataBase);
            SqlDataReader myReader;
            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();

                while (myReader.Read())
                {
                    string sName = myReader.GetString(2);
                 


                    CmbManager.Items.Add(sName);

                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }


        }

        string Gender;

        private void btnCreate_Click(object sender, EventArgs e)
        {

            string constring = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\gafar\OneDrive\Desktop\Onboarding Bayer\Onboarding Bayer\BayerDatabase.mdf;Integrated Security=True";
          //  SELECT EMPLOYEE.FirstName, EMPLOYEE.LastName, EMPLOYEE.PDStartDate, ROLE.Role,Percentage FROM(SELECT EmployeeStep.EmployeeId, (100 * (COUNT(CASE WHEN EmployeeStep.StatusId = '2' THEN 2 END)) / (select COUNT(StepName) From Step)) AS Percentage FROM EmployeeStep GROUP BY EmployeeStep.EmployeeId) Calc RIGHT JOIN EMPLOYEE ON Calc.EmployeeId = EMPLOYEE.EID LEFT JOIN ROLE ON EMPLOYEE.RoleId = ROLE.RoleId ", sqlcon
             string Query = "insert into EMPLOYEE(LastName,FirstName,UserId,RoleId,ADMINID,Gender,HireStatus,HireType,PDstartDate,ManagerComment) values('" + this.txtLName.Text + "','" + this.txtFName.Text + "','" + this.txtUserId.Text + "','" + this.CmbRole.SelectedIndex + "','" + this.CmbManager.SelectedIndex + "','" + Gender + "','" + this.cmbHireStatus.Text + "','" + this.cmbHireType.Text + "','" + this.dtpStartDate.Text + "','" + this.txtManagerC.Text + "');";
           // string Query = "insert into EMPLOYEE(LastName,FirstName,UserId,RoleId,Manager,Gender,HireStatus,HireType,PDstartDate,ManagerComment) values('" + this.txtLName.Text + "','" + this.txtFName.Text + "','" + this.txtUserId.Text + "','"  + ( SELECT RoleId From Role WHERE Role.RoleId = this.txtRole.Text ) +  "','" + this.txtManager.Text + "','" + Gender + "','" + this.cmbHireStatus.Text + "','" + this.cmbHireType.Text + "','" + this.dtpStartDate.Text + "','" + this.txtManagerC.Text + "');";

            SqlConnection conDataBase = new SqlConnection(constring);
                SqlCommand cmdDataBase = new SqlCommand(Query, conDataBase);
                SqlDataReader myReader;
                try
                {
                    conDataBase.Open();
                    myReader = cmdDataBase.ExecuteReader();
                    MessageBox.Show("Successfully Created");
                    ClearField();
                    while (myReader.Read())
                    {

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            
           



            
        


            // con.Open();
            // SqlCommand cmd = con.CreateCommand();
            // cmd.CommandType = CommandType.Text;
            // cmd.CommandText = "insert into EMPLOYEE (LastName,FirstName,UserId,Role,Manager,Gender,HireStatus,HireType,PDstartDate,ManagerComment)values('"+txtLName.Text+"','"+ txtFName.Text+"','"+ txtUserId.Text+ "','" + txtRole.Text + "','" + txtManager.Text + "','" + Gender + "','" + cmbHireStatus.Text + "','" + cmbHireType.Text + "','" + dtpStartDate.Text + "','" + txtManagerC.Text + "')";
            //  con.Close();

            // MessageBox.Show("New Hire Successfully Created");
        }

        private void rbMale_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "Male";
        }

        private void rbFemale_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "Female";
        }

        public  void ClearField() {
            txtLName.Text = "";
            txtFName.Text = "";
            txtUserId.Text = "";
            CmbRole.Text = "";
            CmbManager.Text = "";
            Gender = "";
            cmbHireStatus.Text = "";
            cmbHireType.Text = "";
            dtpStartDate.Text = "";
            txtManagerC.Text = "";

        }

        private void btnCreateCancel_Click(object sender, EventArgs e)
        {
            ClearField();

        }
    }
}
