﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Onboarding_Bayer
{
    public partial class Complete : UserControl
    { 
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\gafar\OneDrive\Desktop\Onboarding Bayer\Onboarding Bayer\BayerDatabase.mdf;Integrated Security=True";

        private static Complete _instance;

    public static Complete Instance
    {
        get
        {
            if (_instance == null)
                _instance = new Complete();
            return _instance;

        }

    }
    public Complete()
        {
            InitializeComponent();
            Load_data();
        }

        public void Load_data()
        {

            using (SqlConnection sqlcon = new SqlConnection(connectionString))
            {

                sqlcon.Open();
                // SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, EMPLOYEE.LastName, EMPLOYEE.PDStartDate, ROLEE.Role FROM EMPLOYEE LEFT JOIN ROLEE ON EMPLOYEE.RoleId = ROLEE.RoleId", sqlcon);
                // SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EmployeeStep.EmployeeId, (((COUNT(*) From EmployeeStep Where StatusId IN ('1') Group by EmployeeId)/ (Count(StepName) from Step))*100) AS Percentage FROM EmployeeStep JOIN EMPLOYEE ON EmployeeStep.EmployeeId = EMPLOYEE.EId;", sqlcon);
                // SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EmployeeId,(100*(COUNT (CASE WHEN StatusId ='1' THEN 1 END ))/( select COUNT(StepName) From Step)) AS Percentage FROM EmployeeStep GROUP BY EmployeeId;", sqlcon);
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, Percentage FROM ( SELECT EmployeeStep.EmployeeId,(100*(COUNT (CASE WHEN EmployeeStep.StatusId ='2' THEN 2 END ))/( select COUNT(StepName) From Step)) AS Percentage FROM EmployeeStep GROUP BY EmployeeStep.EmployeeId) Calc RIGHT JOIN EMPLOYEE ON Calc.EmployeeId = EMPLOYEE.EID;", sqlcon);
                 
                DataTable dtb1 = new DataTable();
                sqlDa.Fill(dtb1);
                DGVCompletion.AutoGenerateColumns = false;
                DGVCompletion.DataSource = dtb1;


            }

        }

        // public void load_data()
        //  {

        //   using (SqlConnection sqlcon = new SqlConnection(connectionString))
        ///  {

        //  sqlcon.Open();
        // SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, EMPLOYEE.LastName, EMPLOYEE.PDStartDate, ROLEE.Role FROM EMPLOYEE LEFT JOIN ROLEE ON EMPLOYEE.RoleId = ROLEE.RoleId", sqlcon);
        //  SqlDataAdapter sqlDa = new SqlDataAdapter(" SELECT EmployeeId, StatusId, StepId FROM EmployeeStep WHERE EmployeeId = 1 AND StepId = 1", sqlcon);
        //  DataTable dtb1 = new DataTable();
        // sqlDa.Fill(dtb1);
        //  dgvCompletion.AutoGenerateColumns = false;
        /// dgvCompletion.DataSource = dtb1;
        //    }

        //   }

    }
}
