﻿namespace Onboarding_Bayer
{
    partial class Complete
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblCompletion = new System.Windows.Forms.Label();
            this.DGVCompletion = new System.Windows.Forms.DataGridView();
            this.FirstName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Percentage = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.DGVCompletion)).BeginInit();
            this.SuspendLayout();
            // 
            // LblCompletion
            // 
            this.LblCompletion.AutoSize = true;
            this.LblCompletion.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCompletion.Location = new System.Drawing.Point(19, 18);
            this.LblCompletion.Name = "LblCompletion";
            this.LblCompletion.Size = new System.Drawing.Size(342, 46);
            this.LblCompletion.TabIndex = 0;
            this.LblCompletion.Text = "Completion Page";
            // 
            // DGVCompletion
            // 
            this.DGVCompletion.AllowUserToAddRows = false;
            this.DGVCompletion.AllowUserToDeleteRows = false;
            this.DGVCompletion.AllowUserToOrderColumns = true;
            this.DGVCompletion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVCompletion.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FirstName,
            this.Percentage});
            this.DGVCompletion.Location = new System.Drawing.Point(56, 96);
            this.DGVCompletion.Name = "DGVCompletion";
            this.DGVCompletion.ReadOnly = true;
            this.DGVCompletion.Size = new System.Drawing.Size(415, 228);
            this.DGVCompletion.TabIndex = 1;
            // 
            // FirstName
            // 
            this.FirstName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.FirstName.DataPropertyName = "FirstName";
            this.FirstName.HeaderText = "Full Name";
            this.FirstName.Name = "FirstName";
            this.FirstName.ReadOnly = true;
            // 
            // Percentage
            // 
            this.Percentage.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Percentage.DataPropertyName = "Percentage";
            this.Percentage.HeaderText = "Progress";
            this.Percentage.Name = "Percentage";
            this.Percentage.ReadOnly = true;
            this.Percentage.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Percentage.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Complete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lime;
            this.Controls.Add(this.DGVCompletion);
            this.Controls.Add(this.LblCompletion);
            this.Name = "Complete";
            this.Size = new System.Drawing.Size(531, 356);
            ((System.ComponentModel.ISupportInitialize)(this.DGVCompletion)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblCompletion;
        private System.Windows.Forms.DataGridView DGVCompletion;
        private System.Windows.Forms.DataGridViewTextBoxColumn FirstName;
        private System.Windows.Forms.DataGridViewButtonColumn Percentage;
    }
}
