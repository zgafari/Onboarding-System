﻿namespace Onboarding_Bayer
{
    partial class ViewCompletion
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("Step");
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("STEPS");
            this.pnNotDone = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.LVNotDone = new System.Windows.Forms.ListView();
            this.colNotDone = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pnInProgress = new System.Windows.Forms.Panel();
            this.LVInProgress = new System.Windows.Forms.ListView();
            this.StepName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label2 = new System.Windows.Forms.Label();
            this.PnDone = new System.Windows.Forms.Panel();
            this.LVDone = new System.Windows.Forms.ListView();
            this.label3 = new System.Windows.Forms.Label();
            this.pnNotDone.SuspendLayout();
            this.pnInProgress.SuspendLayout();
            this.PnDone.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnNotDone
            // 
            this.pnNotDone.Controls.Add(this.label1);
            this.pnNotDone.Controls.Add(this.LVNotDone);
            this.pnNotDone.Location = new System.Drawing.Point(3, 0);
            this.pnNotDone.Name = "pnNotDone";
            this.pnNotDone.Size = new System.Drawing.Size(220, 395);
            this.pnNotDone.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(77, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "NOT DONE";
            // 
            // LVNotDone
            // 
            this.LVNotDone.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colNotDone});
            this.LVNotDone.HideSelection = false;
            this.LVNotDone.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1});
            this.LVNotDone.Location = new System.Drawing.Point(16, 77);
            this.LVNotDone.Name = "LVNotDone";
            this.LVNotDone.Size = new System.Drawing.Size(188, 301);
            this.LVNotDone.TabIndex = 0;
            this.LVNotDone.UseCompatibleStateImageBehavior = false;
            this.LVNotDone.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // colNotDone
            // 
            this.colNotDone.Tag = "StepName";
            this.colNotDone.Text = "Step(s)";
            // 
            // pnInProgress
            // 
            this.pnInProgress.Controls.Add(this.LVInProgress);
            this.pnInProgress.Controls.Add(this.label2);
            this.pnInProgress.Location = new System.Drawing.Point(238, 0);
            this.pnInProgress.Name = "pnInProgress";
            this.pnInProgress.Size = new System.Drawing.Size(220, 395);
            this.pnInProgress.TabIndex = 1;
            // 
            // LVInProgress
            // 
            this.LVInProgress.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.StepName});
            this.LVInProgress.HideSelection = false;
            listViewItem2.ToolTipText = "STEPS";
            this.LVInProgress.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem2});
            this.LVInProgress.Location = new System.Drawing.Point(16, 77);
            this.LVInProgress.Name = "LVInProgress";
            this.LVInProgress.Size = new System.Drawing.Size(179, 301);
            this.LVInProgress.TabIndex = 1;
            this.LVInProgress.UseCompatibleStateImageBehavior = false;
            this.LVInProgress.SelectedIndexChanged += new System.EventHandler(this.LVInProgress_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(77, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "IN PROGRESS";
            // 
            // PnDone
            // 
            this.PnDone.Controls.Add(this.LVDone);
            this.PnDone.Controls.Add(this.label3);
            this.PnDone.Location = new System.Drawing.Point(478, 0);
            this.PnDone.Name = "PnDone";
            this.PnDone.Size = new System.Drawing.Size(222, 395);
            this.PnDone.TabIndex = 2;
            // 
            // LVDone
            // 
            this.LVDone.HideSelection = false;
            this.LVDone.Location = new System.Drawing.Point(24, 77);
            this.LVDone.Name = "LVDone";
            this.LVDone.Size = new System.Drawing.Size(169, 301);
            this.LVDone.TabIndex = 1;
            this.LVDone.UseCompatibleStateImageBehavior = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(85, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "DONE";
            // 
            // ViewCompletion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lime;
            this.Controls.Add(this.PnDone);
            this.Controls.Add(this.pnInProgress);
            this.Controls.Add(this.pnNotDone);
            this.Name = "ViewCompletion";
            this.Size = new System.Drawing.Size(703, 401);
            this.Load += new System.EventHandler(this.ViewCompletion_Load);
            this.pnNotDone.ResumeLayout(false);
            this.pnNotDone.PerformLayout();
            this.pnInProgress.ResumeLayout(false);
            this.pnInProgress.PerformLayout();
            this.PnDone.ResumeLayout(false);
            this.PnDone.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnNotDone;
        private System.Windows.Forms.Panel pnInProgress;
        private System.Windows.Forms.Panel PnDone;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView LVNotDone;
        private System.Windows.Forms.ListView LVInProgress;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListView LVDone;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ColumnHeader colNotDone;
        private System.Windows.Forms.ColumnHeader StepName;
    }
}
