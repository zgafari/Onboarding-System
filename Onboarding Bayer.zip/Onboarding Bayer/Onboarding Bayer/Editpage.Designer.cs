﻿namespace Onboarding_Bayer
{
    partial class Editpage
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbCreateNew = new System.Windows.Forms.GroupBox();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtManagerC = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbHireType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbHireStatus = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.rbFemale = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.rbMale = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.txtManager = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtRole = new System.Windows.Forms.TextBox();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.txtUserId = new System.Windows.Forms.TextBox();
            this.btnEditCancel = new System.Windows.Forms.Button();
            this.btnDone = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbRegionalLocation = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtVendor = new System.Windows.Forms.TextBox();
            this.cmbPLIC = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtTeamName = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtPlatform = new System.Windows.Forms.TextBox();
            this.cmbOnboarding = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbComputerNeeds = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtSeatNumber = new System.Windows.Forms.TextBox();
            this.gbCreateNew.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbCreateNew
            // 
            this.gbCreateNew.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbCreateNew.Controls.Add(this.label18);
            this.gbCreateNew.Controls.Add(this.txtSeatNumber);
            this.gbCreateNew.Controls.Add(this.cmbComputerNeeds);
            this.gbCreateNew.Controls.Add(this.label17);
            this.gbCreateNew.Controls.Add(this.cmbOnboarding);
            this.gbCreateNew.Controls.Add(this.label16);
            this.gbCreateNew.Controls.Add(this.label15);
            this.gbCreateNew.Controls.Add(this.txtPlatform);
            this.gbCreateNew.Controls.Add(this.label14);
            this.gbCreateNew.Controls.Add(this.txtTeamName);
            this.gbCreateNew.Controls.Add(this.cmbPLIC);
            this.gbCreateNew.Controls.Add(this.label13);
            this.gbCreateNew.Controls.Add(this.label12);
            this.gbCreateNew.Controls.Add(this.txtVendor);
            this.gbCreateNew.Controls.Add(this.cmbRegionalLocation);
            this.gbCreateNew.Controls.Add(this.label11);
            this.gbCreateNew.Controls.Add(this.txtLName);
            this.gbCreateNew.Controls.Add(this.label2);
            this.gbCreateNew.Controls.Add(this.label3);
            this.gbCreateNew.Controls.Add(this.txtManagerC);
            this.gbCreateNew.Controls.Add(this.label4);
            this.gbCreateNew.Controls.Add(this.dtpStartDate);
            this.gbCreateNew.Controls.Add(this.label5);
            this.gbCreateNew.Controls.Add(this.cmbHireType);
            this.gbCreateNew.Controls.Add(this.label6);
            this.gbCreateNew.Controls.Add(this.cmbHireStatus);
            this.gbCreateNew.Controls.Add(this.label7);
            this.gbCreateNew.Controls.Add(this.rbFemale);
            this.gbCreateNew.Controls.Add(this.label8);
            this.gbCreateNew.Controls.Add(this.rbMale);
            this.gbCreateNew.Controls.Add(this.label9);
            this.gbCreateNew.Controls.Add(this.txtManager);
            this.gbCreateNew.Controls.Add(this.label10);
            this.gbCreateNew.Controls.Add(this.txtRole);
            this.gbCreateNew.Controls.Add(this.txtFName);
            this.gbCreateNew.Controls.Add(this.txtUserId);
            this.gbCreateNew.Location = new System.Drawing.Point(88, 66);
            this.gbCreateNew.Name = "gbCreateNew";
            this.gbCreateNew.Size = new System.Drawing.Size(621, 372);
            this.gbCreateNew.TabIndex = 27;
            this.gbCreateNew.TabStop = false;
            this.gbCreateNew.Text = "Edit User";
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(91, 32);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(100, 20);
            this.txtLName.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(247, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "First Name";
            // 
            // txtManagerC
            // 
            this.txtManagerC.Location = new System.Drawing.Point(91, 276);
            this.txtManagerC.Multiline = true;
            this.txtManagerC.Name = "txtManagerC";
            this.txtManagerC.Size = new System.Drawing.Size(276, 59);
            this.txtManagerC.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(463, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "User Id";
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpStartDate.Location = new System.Drawing.Point(481, 145);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(125, 20);
            this.dtpStartDate.TabIndex = 19;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Role";
            // 
            // cmbHireType
            // 
            this.cmbHireType.FormattingEnabled = true;
            this.cmbHireType.Location = new System.Drawing.Point(310, 184);
            this.cmbHireType.Name = "cmbHireType";
            this.cmbHireType.Size = new System.Drawing.Size(121, 21);
            this.cmbHireType.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(247, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Manager";
            // 
            // cmbHireStatus
            // 
            this.cmbHireStatus.FormattingEnabled = true;
            this.cmbHireStatus.Location = new System.Drawing.Point(91, 159);
            this.cmbHireStatus.Name = "cmbHireStatus";
            this.cmbHireStatus.Size = new System.Drawing.Size(121, 21);
            this.cmbHireStatus.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(26, 159);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Hire Status";
            // 
            // rbFemale
            // 
            this.rbFemale.AutoSize = true;
            this.rbFemale.Location = new System.Drawing.Point(485, 92);
            this.rbFemale.Name = "rbFemale";
            this.rbFemale.Size = new System.Drawing.Size(59, 17);
            this.rbFemale.TabIndex = 16;
            this.rbFemale.TabStop = true;
            this.rbFemale.Text = "Female";
            this.rbFemale.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(247, 187);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Hire Type";
            // 
            // rbMale
            // 
            this.rbMale.AutoSize = true;
            this.rbMale.Location = new System.Drawing.Point(485, 69);
            this.rbMale.Name = "rbMale";
            this.rbMale.Size = new System.Drawing.Size(48, 17);
            this.rbMale.TabIndex = 15;
            this.rbMale.TabStop = true;
            this.rbMale.Text = "Male";
            this.rbMale.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(478, 120);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Start Date";
            // 
            // txtManager
            // 
            this.txtManager.Location = new System.Drawing.Point(310, 75);
            this.txtManager.Name = "txtManager";
            this.txtManager.Size = new System.Drawing.Size(100, 20);
            this.txtManager.TabIndex = 14;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(88, 250);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(103, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Manager\'s Comment";
            // 
            // txtRole
            // 
            this.txtRole.Location = new System.Drawing.Point(91, 68);
            this.txtRole.Name = "txtRole";
            this.txtRole.Size = new System.Drawing.Size(100, 20);
            this.txtRole.TabIndex = 13;
            // 
            // txtFName
            // 
            this.txtFName.Location = new System.Drawing.Point(310, 28);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(100, 20);
            this.txtFName.TabIndex = 11;
            // 
            // txtUserId
            // 
            this.txtUserId.Location = new System.Drawing.Point(510, 36);
            this.txtUserId.Name = "txtUserId";
            this.txtUserId.Size = new System.Drawing.Size(100, 20);
            this.txtUserId.TabIndex = 12;
            // 
            // btnEditCancel
            // 
            this.btnEditCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEditCancel.Location = new System.Drawing.Point(520, 444);
            this.btnEditCancel.Name = "btnEditCancel";
            this.btnEditCancel.Size = new System.Drawing.Size(75, 23);
            this.btnEditCancel.TabIndex = 26;
            this.btnEditCancel.Text = "Cancel";
            this.btnEditCancel.UseVisualStyleBackColor = true;
            // 
            // btnDone
            // 
            this.btnDone.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDone.Location = new System.Drawing.Point(618, 444);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(75, 23);
            this.btnDone.TabIndex = 25;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(80, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 46);
            this.label1.TabIndex = 24;
            this.label1.Text = "Edit User";
            // 
            // cmbRegionalLocation
            // 
            this.cmbRegionalLocation.FormattingEnabled = true;
            this.cmbRegionalLocation.Location = new System.Drawing.Point(105, 204);
            this.cmbRegionalLocation.Name = "cmbRegionalLocation";
            this.cmbRegionalLocation.Size = new System.Drawing.Size(121, 21);
            this.cmbRegionalLocation.TabIndex = 22;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 204);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(93, 13);
            this.label11.TabIndex = 21;
            this.label11.Text = "Regional Location";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(247, 226);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 13);
            this.label12.TabIndex = 23;
            this.label12.Text = "Vendor";
            // 
            // txtVendor
            // 
            this.txtVendor.Location = new System.Drawing.Point(310, 223);
            this.txtVendor.Name = "txtVendor";
            this.txtVendor.Size = new System.Drawing.Size(100, 20);
            this.txtVendor.TabIndex = 24;
            // 
            // cmbPLIC
            // 
            this.cmbPLIC.FormattingEnabled = true;
            this.cmbPLIC.Location = new System.Drawing.Point(485, 187);
            this.cmbPLIC.Name = "cmbPLIC";
            this.cmbPLIC.Size = new System.Drawing.Size(121, 21);
            this.cmbPLIC.TabIndex = 26;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(444, 191);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 13);
            this.label13.TabIndex = 25;
            this.label13.Text = "PL/IC";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(239, 117);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 13);
            this.label14.TabIndex = 27;
            this.label14.Text = "Team Name";
            // 
            // txtTeamName
            // 
            this.txtTeamName.Location = new System.Drawing.Point(310, 117);
            this.txtTeamName.Name = "txtTeamName";
            this.txtTeamName.Size = new System.Drawing.Size(100, 20);
            this.txtTeamName.TabIndex = 28;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(28, 110);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(45, 13);
            this.label15.TabIndex = 29;
            this.label15.Text = "Platform";
            // 
            // txtPlatform
            // 
            this.txtPlatform.Location = new System.Drawing.Point(91, 110);
            this.txtPlatform.Name = "txtPlatform";
            this.txtPlatform.Size = new System.Drawing.Size(100, 20);
            this.txtPlatform.TabIndex = 30;
            // 
            // cmbOnboarding
            // 
            this.cmbOnboarding.FormattingEnabled = true;
            this.cmbOnboarding.Location = new System.Drawing.Point(310, 151);
            this.cmbOnboarding.Name = "cmbOnboarding";
            this.cmbOnboarding.Size = new System.Drawing.Size(121, 21);
            this.cmbOnboarding.TabIndex = 32;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(217, 154);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(95, 13);
            this.label16.TabIndex = 31;
            this.label16.Text = "Onboarding Buddy";
            // 
            // cmbComputerNeeds
            // 
            this.cmbComputerNeeds.FormattingEnabled = true;
            this.cmbComputerNeeds.Location = new System.Drawing.Point(514, 218);
            this.cmbComputerNeeds.Name = "cmbComputerNeeds";
            this.cmbComputerNeeds.Size = new System.Drawing.Size(92, 21);
            this.cmbComputerNeeds.TabIndex = 34;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(429, 221);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(86, 13);
            this.label17.TabIndex = 33;
            this.label17.Text = "Computer Needs";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(435, 262);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(69, 13);
            this.label18.TabIndex = 35;
            this.label18.Text = "Seat Number";
            // 
            // txtSeatNumber
            // 
            this.txtSeatNumber.Location = new System.Drawing.Point(505, 259);
            this.txtSeatNumber.Name = "txtSeatNumber";
            this.txtSeatNumber.Size = new System.Drawing.Size(100, 20);
            this.txtSeatNumber.TabIndex = 36;
            // 
            // Editpage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.Lime;
            this.Controls.Add(this.gbCreateNew);
            this.Controls.Add(this.btnEditCancel);
            this.Controls.Add(this.btnDone);
            this.Controls.Add(this.label1);
            this.Name = "Editpage";
            this.Size = new System.Drawing.Size(788, 496);
            this.gbCreateNew.ResumeLayout(false);
            this.gbCreateNew.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbCreateNew;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtSeatNumber;
        private System.Windows.Forms.ComboBox cmbComputerNeeds;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cmbOnboarding;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtPlatform;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtTeamName;
        private System.Windows.Forms.ComboBox cmbPLIC;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtVendor;
        private System.Windows.Forms.ComboBox cmbRegionalLocation;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtManagerC;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbHireType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbHireStatus;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton rbFemale;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton rbMale;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtManager;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtRole;
        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.TextBox txtUserId;
        private System.Windows.Forms.Button btnEditCancel;
        private System.Windows.Forms.Button btnDone;
        private System.Windows.Forms.Label label1;
    }
}
