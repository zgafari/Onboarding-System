﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Onboarding_Bayer
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            //Coonect to database
              SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\gafar\OneDrive\Desktop\Onboarding Bayer\Onboarding Bayer\BayerDatabase.mdf;Integrated Security=True;");
           

            //Select data from the database, sql query

            SqlDataAdapter sd = new SqlDataAdapter("select count(*) from ADMIN where UserId ='" + txtuserid.Text + "' and LoginRole like 'Manager%' ", conn);
            //create Data table
            DataTable dt = new DataTable();
            //fill the data with data table
            sd.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1") 
            {
                SqlDataAdapter sda = new SqlDataAdapter("select count(*) from ADMIN where UserId ='" + txtuserid.Text + "' and password ='" + txtpassword.Text + "'", conn);
                // create Data table
                DataTable dta = new DataTable();
                //fill the data with data table
                 sda.Fill(dta);
                //if count is = 1, then correct. if 0, message box
                if (dta.Rows[0][0].ToString() == "1")
                {
                    //call class 
                    ProfileClass.username = txtuserid.Text;
                    // When login is clicked, hide login form and show onboarding form
                    this.Hide();
                    BayerOnboarding bon = new BayerOnboarding();
                    bon.Show();
                 
                }
                else MessageBox.Show("Incorrect Password", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        
          else MessageBox.Show("Admin Only", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);
            
            
        
        }




    private void btnreset_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
