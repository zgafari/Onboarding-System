﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Onboarding_Bayer
{
    public partial class BayerOnboarding : Form
    {
         string conn = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\gafar\OneDrive\Desktop\Onboarding Bayer\Onboarding Bayer\BayerDatabase.mdf;Integrated Security=True";

        public BayerOnboarding()
        {
            InitializeComponent();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to Logout? Yes/No", "Logout", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                this.Hide();
                LoginForm form = new LoginForm();
                form.Show();
                
            }
        }

        private void BayerOnboarding_Load(object sender, EventArgs e)
        {
            ProfileLabel.Text = ProfileClass.username;

            if (!MainPanel.Controls.Contains(Dashboard.Instance))
            {
                MainPanel.Controls.Add(Dashboard.Instance);
                Dashboard.Instance.Dock = DockStyle.Fill;
                Dashboard.Instance.BringToFront();
            }
            else
                Dashboard.Instance.BringToFront();



            // TODO: This line of code loads data into the 'database1DataSet.EMPLOYEE' table. You can move, or remove it, as needed.
            //  using (SqlConnection sqlcon = new SqlConnection(connectionString))
            //  {

            // sqlcon.Open();
            //  ProfileLabel.Text = sqlcon;
            // SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM EMPLOYEE ", sqlcon);
            // DataTable dtb1 = new DataTable();
            // sqlDa.Fill(dtb1);
            //  DGVDashboard.AutoGenerateColumns = false;
            //  DGVDashboard.DataSource = dtb1;
            //   }

            // this.eMPLOYEETableAdapter.Fill(this.database1DataSet.EMPLOYEE);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlDataAdapter sd = new SqlDataAdapter("select count(*) from ADMIN where UserId ='" + ProfileLabel.Text + "' and Role like 'Manager%' OR Role like 'Admin%' ", conn);
            //create Data table
            DataTable dt = new DataTable();
            //fill the data with data table
            sd.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {


                //  CreatePanel.Visible = true;
                //  DashboardPanel.Visible = false;
                if (!MainPanel.Controls.Contains(Createnew.Instance))
                {
                    MainPanel.Controls.Add(Createnew.Instance);
                    Createnew.Instance.Dock = DockStyle.Fill;
                    Createnew.Instance.BringToFront();
                }
                else
                    Createnew.Instance.BringToFront();
            }
            else MessageBox.Show("Admin/Manager Only", "alert", MessageBoxButtons.OK, MessageBoxIcon.Error);



            }

        private void button1_Click(object sender, EventArgs e)
        {
            //  DashboardPanel.Visible = true;
            //  CreatePanel.Visible = false;

            if (!MainPanel.Controls.Contains(Dashboard.Instance))
            {
                MainPanel.Controls.Add(Dashboard.Instance);
                Dashboard.Instance.Dock = DockStyle.Fill;
                Dashboard.Instance.BringToFront();
            }
            else
                Dashboard.Instance.BringToFront();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!MainPanel.Controls.Contains(Complete.Instance))
            {
                MainPanel.Controls.Add(Complete.Instance);
                Complete.Instance.Dock = DockStyle.Fill;
                Complete.Instance.BringToFront();
            }
            else
                Complete.Instance.BringToFront();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!MainPanel.Controls.Contains(Report.Instance))
            {
                MainPanel.Controls.Add(Report.Instance);
                Report.Instance.Dock = DockStyle.Fill;
                Report.Instance.BringToFront();
            }
            else
                Report.Instance.BringToFront();
        }

        private void ProfileLabel_Click(object sender, EventArgs e)
        {
            ProfileLabel.Text = ProfileClass.username;
        }
    }
}
