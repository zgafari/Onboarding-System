﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Onboarding_Bayer
{
    class ProfileClass
    {
        static string userName;
        public static string username
        {

            get
            {
                return userName;
            }
            set
            {
                userName = value;
            }
        }
    }
}
