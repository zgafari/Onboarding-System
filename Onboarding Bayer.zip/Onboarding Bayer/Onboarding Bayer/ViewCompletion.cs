﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Onboarding_Bayer
{
    public partial class ViewCompletion : UserControl
    {

       SqlConnection sqlcon = new SqlConnection ( @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\gafar\OneDrive\Desktop\Onboarding Bayer\Onboarding Bayer\BayerDatabase.mdf;Integrated Security=True");

        public ViewCompletion()
        {
            InitializeComponent();
        }

        private void ViewCompletion_Load(object sender, EventArgs e)
        {
           
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
          

                sqlcon.Open();
            //  SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, Percentage FROM ( SELECT EmployeeStep.EmployeeId,(100*(COUNT (CASE WHEN EmployeeStep.StatusId ='2' THEN 2 END ))/( select COUNT(StepName) From Step)) AS Percentage FROM EmployeeStep GROUP BY EmployeeStep.EmployeeId) Calc RIGHT JOIN EMPLOYEE ON Calc.EmployeeId = EMPLOYEE.EID;", sqlcon);
           // SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, Percentage FROM ( SELECT EmployeeStep.EmployeeId,(100*(COUNT (CASE WHEN EmployeeStep.StatusId ='2' THEN 2 END ))/( select COUNT(StepName) From Step)) AS Percentage FROM EmployeeStep GROUP BY EmployeeStep.EmployeeId) Calc RIGHT JOIN EMPLOYEE ON Calc.EmployeeId = EMPLOYEE.EID;", sqlcon);

            DataTable dtb1 = new DataTable();
             //   sqlDa.Fill(dtb1);
            for (int i = 0; i < dtb1.Rows.Count; i++) {

                DataRow dr = dtb1.Rows[i];

                ListViewItem itm = new ListViewItem(dr["StepName"].ToString());
                LVNotDone.Items.Add(itm);
            }


            
        }

        private void LVInProgress_SelectedIndexChanged(object sender, EventArgs e)
        {

            sqlcon.Open();
            //  SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, Percentage FROM ( SELECT EmployeeStep.EmployeeId,(100*(COUNT (CASE WHEN EmployeeStep.StatusId ='2' THEN 2 END ))/( select COUNT(StepName) From Step)) AS Percentage FROM EmployeeStep GROUP BY EmployeeStep.EmployeeId) Calc RIGHT JOIN EMPLOYEE ON Calc.EmployeeId = EMPLOYEE.EID;", sqlcon);
            //SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, Percentage FROM ( SELECT EmployeeStep.EmployeeId,(100*(COUNT (CASE WHEN EmployeeStep.StatusId ='2' THEN 2 END ))/( select COUNT(StepName) From Step)) AS Percentage FROM EmployeeStep GROUP BY EmployeeStep.EmployeeId) Calc RIGHT JOIN EMPLOYEE ON Calc.EmployeeId = EMPLOYEE.EID;", sqlcon);

            DataTable dtb1 = new DataTable();
           // sqlDa.Fill(dtb1);
            for (int i = 0; i < dtb1.Rows.Count; i++)
            {

                DataRow dr = dtb1.Rows[i];

                ListViewItem itm = new ListViewItem(dr["StepName"].ToString());
                LVInProgress.Items.Add(itm);
            }
        }
    }
}
