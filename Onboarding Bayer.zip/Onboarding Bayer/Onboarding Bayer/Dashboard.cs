﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Onboarding_Bayer
{
    public partial class Dashboard : UserControl

    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\gafar\OneDrive\Desktop\Onboarding Bayer\Onboarding Bayer\BayerDatabase.mdf;Integrated Security=True";

        private static Dashboard _instance;

            public static Dashboard Instance
        { 
        get
            {
             if (_instance == null)
                _instance = new Dashboard();
                return _instance;

            }

        }

        public Dashboard()
        {
            InitializeComponent();
            load_data();
           

        }
        public void load_data() {

            using (SqlConnection sqlcon = new SqlConnection(connectionString))
            {

                sqlcon.Open();
                //  ProfileLabel.Text = sqlcon;
                //  SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, EMPLOYEE.RoleId, ROLEE.Role, EMPLOYEE.StartDate FROM EMPLOYEE, ROLEE JOIN ROLEE ON EMPLOYEE.RoleId = ROLEE.RoleId ORDER BY EMPLOYEE.FirstName", sqlcon);
                // SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, EMPLOYEE.LastName, EMPLOYEE.PDStartDate, ROLE.Role FROM EMPLOYEE LEFT JOIN ROLE ON EMPLOYEE.RoleId = ROLE.RoleId", sqlcon);
                
               
                SqlDataAdapter update = new SqlDataAdapter("UPDATE EmployeeStep SET CurrentStep = CASE WHEN(StatusId = 1) THEN StepId ELSE NULL END", sqlcon);

                // SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, EMPLOYEE.LastName, EMPLOYEE.PDStartDate, ROLE.Role, Step.StepName, Percentage FROM(SELECT EmployeeStep.EmployeeId, (100 * (COUNT(CASE WHEN EmployeeStep.StatusId = '2' THEN 2 END)) / (select COUNT(StepName) From Step)) AS Percentage FROM EmployeeStep GROUP BY EmployeeStep.EmployeeId) Calc RIGHT JOIN EMPLOYEE ON Calc.EmployeeId = EMPLOYEE.EID LEFT JOIN ROLE ON EMPLOYEE.RoleId = ROLE.RoleId RIGHT JOIN EmployeeStep ON EmployeeStep.CurrentStep = Step.StepId", sqlcon);
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, EMPLOYEE.LastName, EMPLOYEE.PDStartDate, ROLE.Role,Percentage FROM(SELECT EmployeeStep.EmployeeId, (100 * (COUNT(CASE WHEN EmployeeStep.StatusId = '2' THEN 2 END)) / (select COUNT(StepName) From Step)) AS Percentage FROM EmployeeStep GROUP BY EmployeeStep.EmployeeId) Calc RIGHT JOIN EMPLOYEE ON Calc.EmployeeId = EMPLOYEE.EID LEFT JOIN ROLE ON EMPLOYEE.RoleId = ROLE.RoleId ", sqlcon);
                //      ALTER TABLE EmployeeStep
                //ADD CurrentStep AS
                //CASE
                //WHEN(Status = 1) THEN '1'
                //ELSE '2'
                //END
                //;

                DataTable dtb1 = new DataTable();
                sqlDa.Fill(dtb1);
                dgvODashboard.AutoGenerateColumns = false;
                dgvODashboard.DataSource = dtb1;
            }

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            load_data();
        }

        private void txtDSearch_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection sqlcon = new SqlConnection(connectionString))
            {
                    
                sqlcon.Open();
                
                
                    SqlDataAdapter sqlDa1 = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, EMPLOYEE.LastName, EMPLOYEE.PDStartDate, ROLE.Role,Percentage FROM(SELECT EmployeeStep.EmployeeId, (100 * (COUNT(CASE WHEN EmployeeStep.StatusId = '2' THEN 2 END)) / (select COUNT(StepName) From Step)) AS Percentage FROM EmployeeStep GROUP BY EmployeeStep.EmployeeId) Calc RIGHT JOIN EMPLOYEE ON Calc.EmployeeId = EMPLOYEE.EID LEFT JOIN ROLE ON EMPLOYEE.RoleId = ROLE.RoleId WHERE CONCAT ('FirstName', 'LastName', 'Role', 'PDStartDate', 'Percentage') LIKE '%" + txtDSearch.Text + "'", sqlcon);

                    DataTable dtb2 = new DataTable();
                    sqlDa1.Fill(dtb2);
                    dgvODashboard.AutoGenerateColumns = false;
                    dgvODashboard.DataSource = dtb2;
                
                if (CmbDSearch.Text == "First Name")
                {

                    SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, EMPLOYEE.LastName, EMPLOYEE.PDStartDate, ROLE.Role,Percentage FROM(SELECT EmployeeStep.EmployeeId, (100 * (COUNT(CASE WHEN EmployeeStep.StatusId = '2' THEN 2 END)) / (select COUNT(StepName) From Step)) AS Percentage FROM EmployeeStep GROUP BY EmployeeStep.EmployeeId) Calc RIGHT JOIN EMPLOYEE ON Calc.EmployeeId = EMPLOYEE.EID LEFT JOIN ROLE ON EMPLOYEE.RoleId = ROLE.RoleId WHERE FirstName LIKE '" + txtDSearch.Text + "%'" , sqlcon);

                    DataTable dtb1 = new DataTable();
                    sqlDa.Fill(dtb1);
                    dgvODashboard.AutoGenerateColumns = false;
                    dgvODashboard.DataSource = dtb1;
                }

                if (CmbDSearch.Text == "Last Name")
                {

                    SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, EMPLOYEE.LastName, EMPLOYEE.PDStartDate, ROLE.Role,Percentage FROM(SELECT EmployeeStep.EmployeeId, (100 * (COUNT(CASE WHEN EmployeeStep.StatusId = '2' THEN 2 END)) / (select COUNT(StepName) From Step)) AS Percentage FROM EmployeeStep GROUP BY EmployeeStep.EmployeeId) Calc RIGHT JOIN EMPLOYEE ON Calc.EmployeeId = EMPLOYEE.EID LEFT JOIN ROLE ON EMPLOYEE.RoleId = ROLE.RoleId WHERE LastName LIKE '" + txtDSearch.Text + "%'", sqlcon);

                    DataTable dtb1 = new DataTable();
                    sqlDa.Fill(dtb1);
                    dgvODashboard.AutoGenerateColumns = false;
                    dgvODashboard.DataSource = dtb1;
                }

                if (CmbDSearch.Text == "Role")
                {

                    SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, EMPLOYEE.LastName, EMPLOYEE.PDStartDate, ROLE.Role,Percentage FROM(SELECT EmployeeStep.EmployeeId, (100 * (COUNT(CASE WHEN EmployeeStep.StatusId = '2' THEN 2 END)) / (select COUNT(StepName) From Step)) AS Percentage FROM EmployeeStep GROUP BY EmployeeStep.EmployeeId) Calc RIGHT JOIN EMPLOYEE ON Calc.EmployeeId = EMPLOYEE.EID LEFT JOIN ROLE ON EMPLOYEE.RoleId = ROLE.RoleId WHERE Role LIKE '" + txtDSearch.Text + "%'", sqlcon);

                    DataTable dtb1 = new DataTable();
                    sqlDa.Fill(dtb1);
                    dgvODashboard.AutoGenerateColumns = false;
                    dgvODashboard.DataSource = dtb1;
                }

                if (CmbDSearch.Text == "Start Date")
                {

                    SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, EMPLOYEE.LastName, EMPLOYEE.PDStartDate, ROLE.Role,Percentage FROM(SELECT EmployeeStep.EmployeeId, (100 * (COUNT(CASE WHEN EmployeeStep.StatusId = '2' THEN 2 END)) / (select COUNT(StepName) From Step)) AS Percentage FROM EmployeeStep GROUP BY EmployeeStep.EmployeeId) Calc RIGHT JOIN EMPLOYEE ON Calc.EmployeeId = EMPLOYEE.EID LEFT JOIN ROLE ON EMPLOYEE.RoleId = ROLE.RoleId WHERE PDStartDate LIKE '" + txtDSearch.Text + "%'", sqlcon);

                    DataTable dtb1 = new DataTable();
                    sqlDa.Fill(dtb1);
                    dgvODashboard.AutoGenerateColumns = false;
                    dgvODashboard.DataSource = dtb1;
                }


                if (CmbDSearch.Text == "Progress")
                {

                    SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT EMPLOYEE.FirstName, EMPLOYEE.LastName, EMPLOYEE.PDStartDate, ROLE.Role,Percentage FROM(SELECT EmployeeStep.EmployeeId, (100 * (COUNT(CASE WHEN EmployeeStep.StatusId = '2' THEN 2 END)) / (select COUNT(StepName) From Step)) AS Percentage FROM EmployeeStep GROUP BY EmployeeStep.EmployeeId) Calc RIGHT JOIN EMPLOYEE ON Calc.EmployeeId = EMPLOYEE.EID LEFT JOIN ROLE ON EMPLOYEE.RoleId = ROLE.RoleId WHERE Percentage LIKE '" + txtDSearch.Text + "%'", sqlcon);

                    DataTable dtb1 = new DataTable();
                    sqlDa.Fill(dtb1);
                    dgvODashboard.AutoGenerateColumns = false;
                    dgvODashboard.DataSource = dtb1;
                }

            }

        }

        private void DataGridView_Click(object sender, EventArgs e)
        {
          //  Editpage edit = new Editpage();
            //edit.txtManager.Text = dgvODashboard.CurrentRow.Cells[0].Value,ToString();

        }
    }
}
