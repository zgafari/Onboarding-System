﻿UPDATE EMPLOYEE
       SET EMPLOYEE.CurrentStep = get.EmployeeStep.CurrentStep
       FROM (
       SELECT  EmployeeId, CurrentStep 
       FROM EmployeeStep
       GROUP BY  EmployeeStep.EmployeeId
       ) AS get 


       WHERE EMPLOYEE.CurrentStep = EmployeeStep.CurrentStep;


  


   